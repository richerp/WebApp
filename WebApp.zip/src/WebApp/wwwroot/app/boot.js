/// <reference path="../node_modules/typescript/lib/lib.es6.d.ts" />
/// <aareference path="../typings/index.d.ts" />
"use strict";
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
require("rxjs/Rx");
var app_1 = require("./app");
platform_browser_dynamic_1.bootstrap(app_1.AppComponent).catch(function (err) { return console.error(err); });
