﻿/// <reference path="../node_modules/typescript/lib/lib.es6.d.ts" />
/// <aareference path="../typings/index.d.ts" />

import {provide} from "@angular/core";
import { bootstrap } from "@angular/platform-browser-dynamic";
import { RouteConfig, ROUTER_DIRECTIVES, ROUTER_PROVIDERS, ROUTER_BINDINGS } from "@angular/router-deprecated";
import {HTTP_BINDINGS, HTTP_PROVIDERS, Headers, RequestOptions, BaseRequestOptions} from "@angular/http";
import { Location, LocationStrategy, HashLocationStrategy } from "@angular/common";
import "rxjs/Rx";

import { AppComponent } from "./app";


bootstrap(AppComponent).catch(err => console.error(err));
