﻿import {Component, OnInit} from "@angular/core";
import * as Enumerable from "linq-es2015";

@Component({
    selector: "appRoot",
	templateUrl: '/htmlpage.html'
})

export class AppComponent implements OnInit {

	Title: string = "";

	constructor() {
        this.Title += "RichErp -";
    }

    ngOnInit() {
		this.Title += "xxxx";

		//when comment this,then compile again, it work normally

		var count = Enumerable.asEnumerable([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
			.Where(a => a % 2 == 1)
			.Count();
		alert(count);
    }
}